export class InputSystem {

}