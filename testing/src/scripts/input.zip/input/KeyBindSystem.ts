import { getCookie } from "@scripts/util";
export class KeyBindSystem {
    public getLocalUserKeybinds() {
        const str = localStorage.getItem("keybinds");
        if(str) {
            const keybinds = JSON.parse(str);
            void keybinds;
        } else {
            return;
        }
        return;
    }
    public async getStoresUserKeybinds() {
        const token = getCookie("accessToken") || getCookie("refreshToken");
        if(token) {
            const response = await fetch("http://hostname:port/api/route", {
                method: "GET",
                headers: {
                    authorization: `Bearer ${token}`
                }
            });
            const keybinds = await response.json();
            void keybinds;
        }
        return;
    }
}